import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import { ArrowDown, ArrowUp, ArrowUpRight, Menu, X } from 'lucide-react';

type RevealProps = {
  children: ReactNode;
  className?: string;
  delay?: 1 | 2 | 3 | 4;
};

const LINKEDIN_URL = 'https://www.linkedin.com/in/muteeb-shahid-026654387/';

const navItems = [
  { label: 'Signal', href: '#signal' },
  { label: 'Capabilities', href: '#field-notes' },
  { label: 'Experience', href: '#experience' },
  { label: 'Connect', href: '#connect' },
];

const experienceItems = [
  {
    number: '01',
    title: 'Discord Server Moderator',
    period: '2025—2026',
    type: 'Community operations',
    description:
      'Configured, tested, and maintained MEE6, Dyno, and Carl-bot to automate moderation, role assignment, logging, and rule enforcement. Worked with admins and moderators to improve community events and server operations.',
  },
  {
    number: '02',
    title: 'Volunteer, AIESEC Lahore',
    period: '2024—2025',
    type: 'Youth engagement',
    description:
      'Organized youth engagement events and outreach programs, contributed to awareness campaigns that improved social-impact reach by 20%, and developed communication strategies for university students.',
  },
  {
    number: '03',
    title: 'Professional CS:GO Gamer',
    period: '2022—Present',
    type: 'Competitive strategy',
    description:
      'Practiced high-pressure team strategy, built communication protocols with teammates, analyzed performance metrics, and developed disciplined decision-making through continual training.',
  },
];

const skillGroups = [
  {
    title: 'Communication & support',
    detail: 'Customer support, stakeholder coordination, professional follow-ups, public speaking, and conflict resolution.',
  },
  {
    title: 'Operations & documentation',
    detail: 'Calendar management, scheduling across time zones, inbox organization, reports, spreadsheets, presentations, and digital filing.',
  },
  {
    title: 'Tech & automation',
    detail: 'Google Workspace, Microsoft Office 365, project-management tools, workflow tools like n8n, online research, and data summaries.',
  },
];

const educationItems = [
  { title: 'Computer Science', school: 'Lahore Garrison University', period: 'Current · 2029 horizon', result: 'Freshman' },
  { title: 'F.Sc. Pre-Engineering', school: 'Fazaia Inter College', period: '2023—2025', result: 'A Grade' },
  { title: 'Secondary School Certificate', school: 'Garrison Academy for Boys', period: '2021—2023', result: 'A1 Grade' },
];

function Reveal({ children, className = '', delay }: RevealProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.12 },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return (
    <div ref={ref} className={`reveal ${visible ? 'is-visible' : ''} ${delay ? `delay-${delay}` : ''} ${className}`}>
      {children}
    </div>
  );
}

function TopBar({ activeSection }: { activeSection: string }) {
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  return (
    <header className="site-header">
      <div className="section-wrap flex h-[4.6rem] items-center justify-between">
        <a
          href="#top"
          data-testid="link-logo"
          className="group flex items-center gap-3"
          onClick={closeMenu}
        >
          <span className="grid h-8 w-8 place-items-center border border-[#ff5c52] text-[#ff5c52] transition-colors group-hover:bg-[#ff5c52] group-hover:text-[#0b0b11]">
            <span className="font-display text-lg">M</span>
          </span>
          <span className="font-mono text-[0.63rem] uppercase tracking-[0.18em] text-[#e0decd]">
            Muteeb / Shahid
          </span>
        </a>

        <nav className="hidden items-center gap-8 md:flex" aria-label="Primary navigation">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              data-testid={`link-nav-${item.label.toLowerCase().replace(' ', '-')}`}
              className={`nav-link ${activeSection === item.href.slice(1) ? 'is-active' : ''}`}
            >
              {item.label}
            </a>
          ))}
          <a
            href={LINKEDIN_URL}
            target="_blank"
            rel="noreferrer"
            data-testid="link-nav-linkedin"
            className="border border-[#ff5c52] px-4 py-2 font-mono text-[0.62rem] uppercase tracking-[0.11em] text-[#ff5c52] transition-colors hover:bg-[#ff5c52] hover:text-[#0b0b11]"
          >
            LinkedIn
          </a>
        </nav>

        <button
          type="button"
          aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
          aria-expanded={menuOpen}
          data-testid="button-mobile-menu"
          className="grid h-10 w-10 place-items-center border border-[#3a3943] text-[#e0decd] md:hidden"
          onClick={() => setMenuOpen((open) => !open)}
        >
          {menuOpen ? <X size={17} strokeWidth={1.5} /> : <Menu size={17} strokeWidth={1.5} />}
        </button>
      </div>
      {menuOpen && (
        <div className="mobile-menu md:hidden">
          <nav className="section-wrap flex flex-col gap-6 py-7" aria-label="Mobile navigation">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                data-testid={`link-mobile-${item.label.toLowerCase().replace(' ', '-')}`}
                className="nav-link text-base"
                onClick={closeMenu}
              >
                {item.label}
              </a>
            ))}
            <a
              href={LINKEDIN_URL}
              target="_blank"
              rel="noreferrer"
              data-testid="link-mobile-linkedin"
              className="nav-link w-fit text-[#ff5c52]"
              onClick={closeMenu}
            >
              LinkedIn / external profile
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}

function Hero() {
  return (
    <section id="top" className="relative flex min-h-[100dvh] items-end overflow-hidden pb-14 pt-36 md:pb-20">
      <div className="hero-grid" aria-hidden="true" />
      <div className="section-wrap relative z-10 w-full">
        <div className="mb-12 flex items-center justify-between gap-6 md:mb-16">
          <div className="section-kicker reveal is-visible">LHR / PK · 2025—</div>
          <div className="hidden items-center gap-3 font-mono text-[0.6rem] uppercase tracking-[0.14em] text-[#777681] sm:flex">
            <span className="h-1.5 w-1.5 rounded-full bg-[#d9ff69]" />
            Quiet signal detected
          </div>
        </div>

        <div className="grid items-end gap-12 lg:grid-cols-[1fr_0.6fr] lg:gap-4">
          <div>
            <Reveal>
              <p className="mb-5 font-mono text-[0.68rem] uppercase tracking-[0.13em] text-[#8f8d99]">
                Personal index / 001<span className="cursor-blink" />
              </p>
            </Reveal>
            <Reveal delay={1}>
              <h1 className="hero-word" aria-label="Muteeb Shahid">
                <span className="hero-name-line hero-name-line--primary" aria-hidden="true">
                  {'Muteeb'.split('').map((letter, index) => (
                    <span className="hero-letter" style={{ '--letter-index': index } as CSSProperties} key={`${letter}-${index}`}>
                      {letter}
                    </span>
                  ))}
                </span>
                <span className="hero-name-line hero-name-line--secondary" aria-hidden="true">
                  {'Shahid'.split('').map((letter, index) => (
                    <span className="hero-letter" style={{ '--letter-index': index + 6 } as CSSProperties} key={`${letter}-${index}`}>
                      {letter}
                    </span>
                  ))}
                </span>
              </h1>
            </Reveal>
            <Reveal delay={2} className="mt-10 max-w-xl">
              <p className="text-balance max-w-lg text-lg leading-relaxed text-[#a7a5aa] md:text-xl">
                A Computer Science freshman from Lahore, building at the intersection of people, systems, and pressure.
              </p>
            </Reveal>
          </div>

          <Reveal delay={3} className="flex justify-start lg:justify-end">
            <div className="relative">
              <div className="signal-orbit" aria-hidden="true">
                <span className="orbit-dot" />
                <div className="orbit-core">
                  <span className="core-mark">M</span>
                </div>
              </div>
              <span className="absolute -bottom-2 left-0 font-mono text-[0.58rem] uppercase tracking-[0.16em] text-[#777681]">
                Keep looking closer
              </span>
            </div>
          </Reveal>
        </div>

        <div className="mt-20 flex items-end justify-between border-t border-[#292831] pt-5 md:mt-24">
          <a href="#signal" data-testid="link-scroll-signal" className="arrow-link">
            Enter the signal <ArrowDown size={15} strokeWidth={1.4} />
          </a>
          <span className="font-mono text-[0.58rem] uppercase tracking-[0.15em] text-[#777681]">Scroll to read</span>
        </div>
      </div>
    </section>
  );
}

function SignalSection() {
  return (
    <section id="signal" className="section-wrap scroll-mt-24 py-28 md:py-40">
      <div className="grid gap-14 lg:grid-cols-[0.8fr_1.2fr] lg:gap-24">
        <Reveal>
          <div className="section-kicker mb-8">01 / The signal</div>
          <div className="crosshair" aria-hidden="true">
            <span>MS / 01</span>
          </div>
        </Reveal>
        <div>
          <Reveal>
            <h2 className="font-display text-balance max-w-3xl text-4xl leading-[0.98] tracking-[-0.05em] text-[#e0decd] md:text-6xl">
              Communication is the through-line.
            </h2>
          </Reveal>
          <Reveal delay={1} className="mt-8 max-w-2xl">
            <p className="text-base leading-8 text-[#9c9aa3] md:text-lg">
              Muteeb is a motivated Computer Science freshman with experience across community moderation, youth
              volunteering, competitive gaming, and day-to-day operations. He brings articulate communication,
              research, organization, and teamwork to fast-moving environments.
            </p>
          </Reveal>
          <Reveal delay={2} className="mt-12 grid max-w-2xl grid-cols-2 gap-8 sm:grid-cols-3">
            <div className="stat-block">
              <div className="stat-value">CS</div>
              <div className="stat-label">Computer Science freshman</div>
            </div>
            <div className="stat-block">
              <div className="stat-value">03</div>
              <div className="stat-label">Experience threads</div>
            </div>
            <div className="stat-block col-span-2 sm:col-span-1">
              <div className="stat-value">02</div>
              <div className="stat-label">Languages in the toolkit</div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

function Marquee() {
  const items = ['Communication', 'Community operations', 'Research', 'Team strategy'];
  return (
    <div className="overflow-hidden border-y border-[#292831] py-5" aria-label="Portfolio themes">
      <div className="marquee">
        {[...items, ...items].map((item, index) => (
          <span className="marquee-item" key={`${item}-${index}`}>
            <b>+</b> {item}
          </span>
        ))}
      </div>
    </div>
  );
}

function FieldNotes() {
  return (
    <section id="field-notes" className="scroll-mt-24 py-28 md:py-36">
      <div className="section-wrap">
        <Reveal className="mb-14 flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div>
            <div className="section-kicker mb-5">02 / Capabilities</div>
            <h2 className="font-display text-4xl tracking-[-0.04em] text-[#e0decd] md:text-5xl">What he brings to the room.</h2>
          </div>
          <p className="max-w-xs font-mono text-[0.65rem] uppercase leading-6 tracking-[0.1em] text-[#777681]">
            Practical skills, built through real responsibility.
          </p>
        </Reveal>

        <div className="grid gap-4 md:grid-cols-12">
          <Reveal delay={1} className="md:col-span-7">
            <article className="signal-card flex min-h-[20rem] flex-col justify-between p-7 md:p-9">
              <div className="flex items-center justify-between">
                <span className="signal-number">A / 01</span>
                <span className="font-mono text-[0.58rem] uppercase tracking-[0.13em] text-[#d9ff69]">Communication</span>
              </div>
              <div>
                <h3 className="max-w-md text-3xl leading-tight text-[#e0decd] md:text-4xl">Make the message land.</h3>
                <p className="mt-5 max-w-lg leading-7 text-[#908e97]">
                  Articulate communication, public speaking, relationship-building, customer support, and the ability
                  to keep stakeholders moving in the same direction.
                </p>
              </div>
            </article>
          </Reveal>

          <Reveal delay={2} className="md:col-span-5">
            <article className="signal-card flex min-h-[20rem] flex-col justify-between bg-[#d9ff69] p-7 text-[#0b0b11] md:p-9">
              <div className="flex items-center justify-between">
                <span className="signal-number text-[#4c5428]">A / 02</span>
                <span className="font-mono text-[0.58rem] uppercase tracking-[0.13em] text-[#4c5428]">Research</span>
              </div>
              <div>
                <h3 className="text-3xl leading-tight md:text-4xl">Find the useful detail.</h3>
                <p className="mt-5 leading-7 text-[#4c5428]">Online research, data gathering, concise summaries, and documentation that stays usable.</p>
              </div>
            </article>
          </Reveal>

          <Reveal delay={3} className="md:col-span-5">
            <article className="signal-card flex min-h-[16rem] flex-col justify-between p-7 md:p-9">
              <div className="flex items-center justify-between">
                <span className="signal-number">A / 03</span>
                <span className="font-mono text-[0.58rem] uppercase tracking-[0.13em] text-[#ff5c52]">Automation</span>
              </div>
              <div>
                <h3 className="text-2xl leading-tight text-[#e0decd] md:text-3xl">Reduce the repeat.</h3>
                <p className="mt-4 leading-7 text-[#908e97]">Productivity and workflow tools, including n8n, used to remove repetitive manual work and keep operations clear.</p>
              </div>
            </article>
          </Reveal>

          <Reveal delay={4} className="md:col-span-7">
            <article className="signal-card flex min-h-[16rem] flex-col justify-between p-7 md:p-9">
              <div className="flex items-center justify-between">
                <span className="signal-number">A / 04</span>
                <span className="font-mono text-[0.58rem] uppercase tracking-[0.13em] text-[#ff5c52]">Teamwork</span>
              </div>
              <div className="flex flex-col justify-between gap-7 sm:flex-row sm:items-end">
                <h3 className="max-w-sm text-2xl leading-tight text-[#e0decd] md:text-3xl">Stay calm when the pace changes.</h3>
                <span className="font-mono text-[0.64rem] uppercase tracking-[0.1em] text-[#777681]">Adapt / coordinate / deliver</span>
              </div>
            </article>
          </Reveal>
        </div>

        <Reveal delay={2} className="mt-16">
          <div className="grid gap-6 border-t border-[#292831] pt-8 md:grid-cols-3">
            {skillGroups.map((group) => (
              <div key={group.title}>
                <h3 className="font-mono text-[0.65rem] uppercase tracking-[0.11em] text-[#d9ff69]">{group.title}</h3>
                <p className="mt-4 leading-7 text-[#908e97]">{group.detail}</p>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Experience() {
  return (
    <section id="experience" className="section-wrap scroll-mt-24 py-28 md:py-40">
      <Reveal className="mb-14">
        <div className="section-kicker mb-5">03 / Experience</div>
        <h2 className="font-display max-w-3xl text-balance text-4xl leading-[1] tracking-[-0.05em] text-[#e0decd] md:text-6xl">
          Three environments. One adaptable operator.
        </h2>
      </Reveal>

      <div className="space-y-0">
        {experienceItems.map((item, index) => (
          <Reveal key={item.title} delay={(Math.min(index + 1, 4) as 1 | 2 | 3 | 4)}>
            <article className="grid items-start gap-7 border-t border-[#292831] py-9 md:grid-cols-[0.14fr_0.3fr_1fr_0.25fr] md:gap-8">
              <div className="font-mono text-[0.62rem] uppercase tracking-[0.13em] text-[#777681]">{item.number}</div>
              <div className="font-mono text-[0.62rem] uppercase tracking-[0.11em] text-[#d9ff69]">{item.period}</div>
              <div>
                <h3 className="font-display text-3xl tracking-[-0.04em] text-[#e0decd] md:text-4xl">{item.title}</h3>
                <p className="mt-4 max-w-2xl leading-7 text-[#9c9aa3]">{item.description}</p>
              </div>
              <div className="font-mono text-[0.6rem] uppercase leading-5 tracking-[0.1em] text-[#777681] md:text-right">{item.type}</div>
            </article>
          </Reveal>
        ))}
        <div className="noise-line">
          <span className="pr-5 font-mono text-[0.62rem] uppercase tracking-[0.13em] text-[#777681]">Experience / verified from CV</span>
        </div>
      </div>
    </section>
  );
}

function Education() {
  return (
    <section className="border-y border-[#292831] bg-[#101017] py-24 md:py-32">
      <div className="section-wrap grid gap-12 lg:grid-cols-[0.55fr_1fr] lg:gap-24">
        <Reveal>
          <div className="section-kicker mb-5">04 / Education</div>
          <div className="font-mono text-[0.63rem] uppercase leading-6 tracking-[0.1em] text-[#777681]">Building the foundation in public.</div>
        </Reveal>
        <Reveal delay={1}>
          <div>
            <h2 className="font-display text-4xl leading-none tracking-[-0.05em] text-[#e0decd] md:text-6xl">
              Learn the theory.
              <br />
              <span className="text-[#ff5c52]">Practice the signal.</span>
            </h2>
            <div className="mt-10 divide-y divide-[#292831] border-y border-[#292831]">
              {educationItems.map((item) => (
                <div className="grid gap-3 py-5 sm:grid-cols-[1fr_1.1fr_auto] sm:items-center sm:gap-6" key={`${item.title}-${item.school}`}>
                  <div className="text-lg text-[#e0decd]">{item.title}</div>
                  <div className="font-mono text-[0.61rem] uppercase tracking-[0.1em] text-[#777681]">{item.school}</div>
                  <div className="font-mono text-[0.61rem] uppercase tracking-[0.1em] text-[#d9ff69] sm:text-right">
                    {item.period} / {item.result}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-10 grid gap-8 border-t border-[#292831] pt-8 sm:grid-cols-2">
              <div>
                <div className="font-mono text-[0.61rem] uppercase tracking-[0.11em] text-[#d9ff69]">Award / 2025</div>
                <p className="mt-3 text-lg text-[#e0decd]">Certificate of Appreciation</p>
                <p className="mt-1 text-[#777681]">AIESEC Lahore</p>
              </div>
              <div>
                <div className="font-mono text-[0.61rem] uppercase tracking-[0.11em] text-[#d9ff69]">Languages</div>
                <p className="mt-3 text-lg text-[#e0decd]">English <span className="text-[#777681]">/ Fluent</span></p>
                <p className="mt-1 text-lg text-[#e0decd]">Urdu <span className="text-[#777681]">/ Native</span></p>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

function Connect() {
  return (
    <section id="connect" className="section-wrap scroll-mt-24 py-28 md:py-40">
      <Reveal>
        <div className="footer-cta p-8 md:p-16">
          <div className="relative z-10 max-w-3xl">
            <div className="section-kicker mb-7 text-[#d9ff69]">05 / Open channel</div>
            <h2 className="font-display text-balance text-5xl leading-[0.93] tracking-[-0.06em] text-[#e0decd] md:text-8xl">
              Keep the signal
              <br />
              <span className="text-[#d9ff69]">open.</span>
            </h2>
            <p className="mt-8 max-w-lg leading-8 text-[#a7a5aa]">
              Open to conversations around sales, business development, community operations, research, and the work
              that keeps a team moving.
            </p>
            <div className="mt-10 grid gap-3 border-y border-[#3a3a38] py-5 text-sm text-[#d9ff69] sm:grid-cols-2">
              <a href="mailto:muteebshahid9@gmail.com" className="transition-colors hover:text-[#e0decd]">
                muteebshahid9@gmail.com
              </a>
              <a href="tel:+923009462965" className="transition-colors hover:text-[#e0decd] sm:text-right">
                +92 300 9462965
              </a>
            </div>
            <a
              href={LINKEDIN_URL}
              target="_blank"
              rel="noreferrer"
              data-testid="link-connect-linkedin"
              className="arrow-link mt-10 border-b border-[#d9ff69] pb-3"
            >
              Open LinkedIn profile <ArrowUpRight size={16} strokeWidth={1.4} />
            </a>
          </div>
        </div>
      </Reveal>
    </section>
  );
}

function Footer() {
  return (
    <footer className="section-wrap border-t border-[#292831] py-8">
      <div className="flex flex-col justify-between gap-5 font-mono text-[0.58rem] uppercase tracking-[0.12em] text-[#777681] sm:flex-row">
        <span data-testid="text-footer-name">Muteeb Shahid / personal index</span>
        <span data-testid="text-footer-location">Lahore, Pakistan</span>
        <a href="#top" data-testid="link-back-top" className="flex items-center gap-2 transition-colors hover:text-[#d9ff69]">
          Back to top <ArrowUp size={13} strokeWidth={1.3} />
        </a>
      </div>
    </footer>
  );
}

function Portfolio() {
  const [activeSection, setActiveSection] = useState('signal');

  useEffect(() => {
    const sections = ['signal', 'field-notes', 'experience', 'connect'];
    const handleScroll = () => {
      const current = sections.reduce((active, id) => {
        const element = document.getElementById(id);
        if (!element) return active;
        return element.getBoundingClientRect().top <= 160 ? id : active;
      }, 'signal');
      setActiveSection(current);
    };
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    document.title = 'Muteeb Shahid — Quiet signal';
  }, []);

  return (
    <div className="portfolio-shell">
      <TopBar activeSection={activeSection} />
      <main>
        <Hero />
        <SignalSection />
        <Marquee />
        <FieldNotes />
        <Experience />
        <Education />
        <Connect />
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return <Portfolio />;
}